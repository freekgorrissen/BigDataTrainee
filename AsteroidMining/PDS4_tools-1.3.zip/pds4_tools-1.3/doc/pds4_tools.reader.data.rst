pds4_tools.reader.data module
=============================

.. automodule:: pds4_tools.reader.data

Classes
-------

.. autosummary::
    PDS_array
    PDS_ndarray
    PDS_marray

Details
-------

.. autoclass:: PDS_array
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: PDS_ndarray
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: PDS_marray
    :members:
    :undoc-members:
    :show-inheritance:

