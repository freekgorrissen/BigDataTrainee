pds4_tools.reader.general_objects module
========================================

.. currentmodule:: pds4_tools.reader.general_objects

Classes
-------

.. autosummary::

    StructureList
    Structure
    Meta_Class
    Meta_Structure

Details
-------

.. autoclass:: StructureList
    :members:
    :special-members: __len__, __getitem__
    :undoc-members:
    :show-inheritance:

.. autoclass:: Structure
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: Meta_Class
    :no-members:
    :show-inheritance:

.. autoclass:: Meta_Structure
    :members:
    :show-inheritance:
